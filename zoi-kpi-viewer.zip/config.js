// Set your n8n host (no trailing slash)
const BASE_URL = "https://zoidashboard.app.n8n.cloud";

// Optional: bearer token if you added auth on your webhooks
const API_TOKEN = ""; // e.g., "my-secret-token"
